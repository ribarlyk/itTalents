
let randomNumber = 7;
let sum = 0;


for (let i = 1; i <= randomNumber; i++) {
  sum += i;
}

console.log(sum);

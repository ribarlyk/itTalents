let n = 4;
let start = 2;
let result = 1;
do {
  result *= start;
  start++;
} while (start <= n);

console.log(result);

let start = 1;
let number = 12;

let sum = 0;

do {
  sum += start;
  start++;
} while (start <= number);

console.log(sum);

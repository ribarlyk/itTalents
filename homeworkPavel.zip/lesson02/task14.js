let n = 22;

for (let i = n; i >= 10; i--) {
  if (i % 7 === 0) {
    console.log(i);
  }
}

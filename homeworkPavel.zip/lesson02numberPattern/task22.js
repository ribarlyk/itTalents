let height =5 ;
let result = "";
let counter = 1;

for(let i = 5;i>=1;i--){
    for(let k = 1;k<=i;k++){
result+=counter;
    }

    console.log(result);
    counter++
result = ''

}
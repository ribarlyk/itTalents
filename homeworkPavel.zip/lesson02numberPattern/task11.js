let start  = 1;
let cycles = 5;
let result = "";

for(let i = 1; i<=cycles;i++){
    for(let j = 1;j<=cycles;j++){
      result+=j
    }
    
    console.log(result);
    result = "";
}
/** Task1. Write a program that prints all numbers between -100 and 100. Then print them
backwards */

// shte tursq ot -100 do 100
// da pokaja vsichki chisla i sled tova v obraten red

for (let i = -100; i <= 100; i++) {
  console.log(i);
}
for (let i = 100; i >= -100; i--) {
  console.log(i);
}

let array = [];

for (let i = 0; i < 10; i++) {
  array.push(i * 3);
}

console.log(array);
